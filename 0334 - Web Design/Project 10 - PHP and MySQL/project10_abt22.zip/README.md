# Project 10 for CS0334 Spring 2018 - Alec Trievel

## Project Description and [Project Link](http://www.alectrievel.com/schoolwork/CS0334/project10/)

For this lab, you are to utlize your XHTML, CSS, PHP, and SQL skills...

Building on what you did in Lab 9, write a program to view, add, and edit records in your customer list.

Also, write a program that asks a user's name and searches the database for that user.
