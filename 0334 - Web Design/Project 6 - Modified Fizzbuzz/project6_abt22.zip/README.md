# Project 6 for CS0334 Spring 2018 - Alec Trievel

## Project Description and [Project Link](http://www.alectrievel.com/schoolwork/CS0334/project6/index.php)

* Write a program that prints the numbers from 1 to 100; but for multiples of three, print "Go" instead of the number, and for multiples of five, print "Pitt".  For numbers which are multiples of both three and five, print "GoPitt".

* Assume that you'll be working with integers only.

