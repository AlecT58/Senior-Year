# Project  for CS0334 Spring 2018 - Alec Trievel

## Project Description and [Project Link](http://www.alectrievel.com/schoolwork/CS0334/project5/index.html)

* Create an HTML page that has a form that asks the user to provide an amount for the number of dice to roll ( let's keep it to between 1 and 5 dice) and his/her guess of what the total sum of all the dice will be.

* Then, provide some feedback to the user as to whether his/her guess was accurate. (remember - check for "defaults"/outlier amounts and give user feedback in that regard also)....

* Then, create a PHP file that will take that data and process it (that is, "roll the dice"!)

* Be sure to display images of the rolled dice, and the numeric total of the dice.
