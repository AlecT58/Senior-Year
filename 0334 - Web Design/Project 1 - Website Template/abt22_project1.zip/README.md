# Project 1 for CS0334 Spring 2018 - Alec Trievel

## Project Description and [Project Link](http://www.alectrievel.com/schoolwork/CS0334/project1/index.html)

### Download a website template that utilizes CSS to create a "Business-related" website (for example, "business & services", or "computing and apps" or "non-profit" or "accounting", etc.); make sure to

1. include all graphics as appropriate
1. maintain the file structure that was downloaded (images in image folder, etc)
1. save the site and publish it to your web host environment

### The folder "My Edits" contains the changes I made to the downloaded source code, located in the "Original Templates" folder