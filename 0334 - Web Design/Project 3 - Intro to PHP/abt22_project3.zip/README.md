# Project 3 for CS0334 Spring 2018 - Alec Trievel

## Project Description and [Project Link](http://www.alectrievel.com/schoolwork/CS0334/project3/index.html)

### Create create the "Tip of the Day" program on page 19 in the book, except you are to use external CSS for the various colors and styles (see also: [lab3_instructions_book_page19.pdf](https://courseweb.pitt.edu/bbcswebdav/pid-24140309-dt-content-rid-22740016_2/courses/2184_UPITT_CS_0334_SEC1020/lab3_instructions_book_page19.pdf) )
