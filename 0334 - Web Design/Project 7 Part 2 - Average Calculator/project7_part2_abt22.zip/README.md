# Project 7 Part 2 for CS0334 Spring 2018 - Alec Trievel

## Project Description and [Project Link](http://www.alectrievel.com/schoolwork/CS0334/project7/part2/part2.php)

* Using an array, calculate a student’s average score on his/her first five lab assignments
* Ask the user to enter 5 scores (each out of a possible 100 points for each assignment)
* Calculate and display the total points scored
* Calculate and display the average score for the 5 assignments