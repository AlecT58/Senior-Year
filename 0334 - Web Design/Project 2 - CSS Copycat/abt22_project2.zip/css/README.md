# Project 2 for CS0334 Spring 2018 - Alec Trievel

## Project Description and [Project Link](http://www.alectrievel.com/schoolwork/CS0334/project2/index.html)

### Create [this](http://www.pitt.edu/~pld7/CS334/table.htm) page, which was created using a table layout, by using CSS and divs - utilizing positioning and/or floats (DO NOT USE TABLES or styles for tables). (Assignment originally designed by Don Bonidie)
