# Project 7 Part 1 for CS0334 Spring 2018 - Alec Trievel

## Project Description and [Project Link](http://www.alectrievel.com/schoolwork/CS0334/project7/part1/part1.php)

* Create an array of the days of the week and then use the array to display the following message:
      The days of the week in sequence are:
               1. Monday
               2. Tuesday
               3. Wednesday
               4. Thursday
               5. Friday
               6. Saturday
               7. Sunday
* Using a form embedded in the php file, ask a user the following:
  * The month of their birth
  * The day of their birth
  * The year of their birth
  * Based on the data entered, using a php function, calculate the actual day of the week they were born, and display the following: You were born on a xxxday!
* Display in tabular format the calendar for that particular month in which the person was born