INSERT INTO Customer VALUES (NULL, 'password', 'alec', 'trievel', '123 main street', 'appartment 2', 'pittsburgh', 'pa', '15213', 'United States', 'abt22@pitt.edu', '123456789', '987654321');
INSERT INTO Customer VALUES (NULL, '1234', 'bob', 'jones', '150 green street', 'room 13', 'pittsburgh', 'pa', '15213', 'United States', 'bob@pitt.edu', '789321456', '741258963');
INSERT INTO Customer VALUES (NULL, 'abc', 'miro', 'baldovoni', '72 chestnut lane', 'appartment 7', 'orlando', 'fl', '32789', 'United States', 'miro@pitt.edu', '753159456', '951357852');
INSERT INTO Customer VALUES (NULL, 'qwerty', 'pomoma', 'wolters', '5565 sixth avenue', 'appartment 6', 'jersey city', 'nj', '07030', 'United States', 'pw@pitt.edu', '159357741', '159963357');
INSERT INTO Customer VALUES (NULL, 'dadsas', 'aaron', 'reijnders', '125 apple road', 'appartment 5', 'seattle', 'wa', '98101', 'United States', 'ar@pitt.edu', '789987147', '789987741');
INSERT INTO Customer VALUES (NULL, 'hjdfhsdh', 'marita', 'goodwin', '72 walnut pass', 'suite 18', 'los angeles', 'ca', '90001', 'United States', 'mg@pitt.edu', '123456789', '987654321');
INSERT INTO Customer VALUES (NULL, '412dsds', 'eloi', 'quick', '654 bluebird avenue', 'room 78', 'columbus', 'oh', '43004', 'United States', 'eq@pitt.edu', '123123123', '123123456');
INSERT INTO Customer VALUES (NULL, '77979dasd', 'kumar', 'altamura', '793 rose lane', 'room 88', 'honolulu', 'hi', '96795', 'United States', 'ka@pitt.edu', '789789789', '789852963');
INSERT INTO Customer VALUES (NULL, 'asda799', 'leon', 'banerjee', '1234 ruby road', 'appartment 12', 'buffalo', 'ny', '14201', 'United States', 'lb@pitt.edu', '456123456', '456789456');
INSERT INTO Customer VALUES (NULL, 'dasdqe97', 'brandon', 'donne', '79 hope avenue', 'suite 2', 'plano', 'tx', '75023', 'United States', 'bd@pitt.edu', '794613312', '741258936');
/*New inserts*/
INSERT INTO Salesperson VALUES (NULL, 'joe', 'cool', '5555 fifth avenue', 'suite 2', 'plano', 'tx', '75023', 'United States', 'jc@pitt.edu', '78965412000', '12374196385', 'facebook.com/joe');
INSERT INTO Salesperson VALUES (NULL, 'george', 'jefferson', '1234 fourth avenue', 'apartment 5', 'pittsburgh', 'pa', '15213', 'United States', 'gj@pitt.edu', '78965412000', '12374196385', 'facebook.com/george');
INSERT INTO Salesperson VALUES (NULL, 'bob', 'ross', '7851 fifth avenue', '', 'pittsburgh', 'pa', '15219', 'United States', 'br@pitt.edu', '32132132100', '000005647892', 'facebook.com/bob');
INSERT INTO Salesperson VALUES (NULL, 'rob', 'blob', '2222 sixth avenue', 'floor 8', 'pittsburgh', 'pa', '15217', 'United States', 'rb@pitt.edu', '78900078900', '8675309101', 'facebook.com/rob');