# Project 9 for CS0334 Spring 2018 - Alec Trievel

## Project Description and [Project Link](http://www.alectrievel.com/schoolwork/CS0334/project9/)

Design a customer contact database that would store at least the following data items:

* last name
* first name
* street address 1
* street address 2
* city
* state
* postal code
* country
* email address
* home phone
* facebook page url
* cell phone
* userid
* password

Using SQL write code to create and populate the database with at least 10 rows of data and perform at least 2 distinct queries of your database and display results based on those queries