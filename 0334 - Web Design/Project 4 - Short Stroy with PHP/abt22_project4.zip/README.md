# Project 4 for CS0334 Spring 2018 - Alec Trievel

## Project Description and [Project Link](http://www.alectrievel.com/schoolwork/CS0334/project4/index.html)

### For the lab, write your own "story" game, similar to the one in Chapter 2.  Find text to modify, create an input form, and output the story with a PHP script
