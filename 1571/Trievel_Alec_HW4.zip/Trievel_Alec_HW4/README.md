# Assignment 4 Programming #

## Description ##

* __Project:__ Assignment 4 for CS1571 Fall 2017
* __Name:__ Alec Trievel
* __Peoplesoft ID:__ 3943128

## Requirements ##

* __Python Version:__ Python 3.6.3
* __Required files:__
  1. NaiveBayes.py
  1. spambase.data
  1. spambase_documentation.txt (in order to parse the averages provided in spambase.DOCUMENTATION)

* __External libraries:__ none

## Program Errors ##

No compliation / runtime errors.
I relaized I forgot to make the txt files for the split of each fold as I was submitting, however.