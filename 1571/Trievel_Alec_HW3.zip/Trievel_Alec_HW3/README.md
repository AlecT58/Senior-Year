# assignment3_programming
Description: Assignment 3 for CS1571 (Final Submission)
Name: Alec Trievel
Peoplesoft ID: 3943128

.NET Framework: 4.6.1
Required files: FOL_FC .cs /.exe and FOL_IFC .cs /.exe
External libraries: none
Resources referenced: our textbook     
People referenced: none